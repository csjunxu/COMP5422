* COMP5422 Lab Assignment


Please run 'test_rgb_hsi' to see the transformation between RGB and HSI color space.

Run 'test_bilinear_cdm' to see the result of bilinear interpolation for color demosaicing.

The results are published in ./html.



QING Pei

11500811G
edwardtoday@gmail.com